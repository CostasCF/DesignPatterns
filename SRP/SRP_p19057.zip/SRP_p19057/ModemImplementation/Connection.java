public interface Connection {
    public void dial();
    public void hungup();
}
