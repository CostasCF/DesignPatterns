public interface DataChannel {
    public void send(char c);
    public void recv();
}